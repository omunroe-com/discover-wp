<div class="post_item post_quotes white_box">
	<div class="post_item_inner">
		<?php the_content(); ?>
		<div class="quote_name">&mdash; <cite><?php the_title(); ?></cite></div>
	</div>
	<a  href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title_attribute(); ?>" class="quote_link"></a>
</div>
